# PLXN ($P_x$)

A minimalist visual project planner and infinite canvas workspace designed to turn scattered ideas into structured, actionable pipelines.

## Overview

PLXN lets you map out complex projects spatially rather than getting lost in rigid tables or linear task lists. Arrange notes, tasks, checklists, and milestones on an infinite 2D canvas, link dependencies with directional flow lines, and track project execution progress in real time.

## Key Features

- **Infinite Spatial Canvas**: Freely pan, zoom (25%–250%), and snap nodes to a clean 24px grid.
- **MS Paint-Style Whiteboard Drawing**:
  - Tablet & stylus ready freehand pen with midpoint curve smoothing for fluid handwriting and drafting.
  - Basic geometric shapes: **Lines**, **Directional Arrows**, **Rectangles**, and **Circles/Ellipses** (with outline or translucent tint fill).
  - Continuous stroke eraser tool with brush-over deletion.
  - Curated color swatches + custom color picker, and 4 stroke weights (Fine, Medium, Bold, Marker).
  - Dedicated **Clear Drawings** action that wipes only drawings while keeping all project nodes, tasks, and connections intact.
  - Full Undo/Redo (`Ctrl+Z` / `Ctrl+Y`) integration for all strokes and shapes.
- **Node Ecosystem**:
  - **Tasks**: Checklists, assignees, due dates, statuses (*To-Do*, *In Progress*, *Done*, *Blocked*), and live progress bars.
  - **Milestones**: Major goals, target dates, and phase status.
  - **Notes & Links**: Rich markdown-styled thoughts and external documentation references.
- **Directional Connectors**: Link cards via 4 directional anchor ports with smooth bezier curves, straight lines, or orthogonal paths (solid, dashed, or animated pulses).
- **Workspace Dashboard**: Filter projects by tags, pinned items, or recent updates, with global search across all plans and cards.
- **Workflow Templates**: Quick-start blueprints including *Product Launch*, *Kanban Sprint*, *Sci-Fi Storyboard*, and *Weekly Focus*.
- **Offline-First & Cloud Sync**: Operates entirely client-side via local storage, with optional Google/Email authentication and automatic real-time sync to **Google Cloud Firestore**.
- **Dark & Light Mode**: Clean, distraction-free aesthetic with instant zero-flash theme persistence and adaptive dot-grid background.
- **Data Portability**: Full Undo/Redo history (`Cmd+Z` / `Cmd+Shift+Z`) and one-click JSON workspace export and import.

## Tech Stack

- **Framework**: [React 19](https://react.dev/) + [TypeScript](https://www.typescriptlang.org/)
- **Bundler & Tooling**: [Vite](https://vitejs.dev/)
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Cloud Backend**: [Firebase](https://firebase.google.com/) (Authentication & Cloud Firestore)

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or bun

### Installation

```bash
# Clone the repository
git clone <repo-url>
cd plxn

# Install dependencies
npm install

# Start local development server
npm run dev
```

Visit `http://localhost:3000` in your browser.

### Building for Production

```bash
npm run build
```

## License

MIT
